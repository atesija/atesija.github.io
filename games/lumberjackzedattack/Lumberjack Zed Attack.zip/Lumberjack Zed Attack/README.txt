Keys:
	Menu:
	Arrow Keys - Move selection
	Enter - Select current
	ESC - Previous menu / Quit

	In game:
	Arrow Keys - Move
	A - Cut down tree (must be underneath it)
	S - Lay down fire trap (Requires 5 lumber)
	P - Pause

How to play:
	Survive as long as possible!
	Zombies do 1 damage if they touch you.
	You have 5 health to start with.
	Lay down fire traps to protect yourself.
	If a zombie hits a trap it dies and leaves behind food.
	Eating the food (Yes it's edible) heals you 1 heart.
	Survivors appear at random intervals.
	Collect them before the zombies do for massive points.

Point breakdown:
	10	Collect lumber
	100	Eat food
	1000	Kill zombie
	2000	Save survivor
	-2500	Zombie kills survivor

Made with:
	C++
	SDL
	SDL_image
	SDL_ttf
	SDL_mixer

Made by:
	Anthony Tesija