#include "structs.h"

class Button{
	Location origin, to;
	SDL_Surface *image;

	Button();
public:
	Button(string file, int x0, int y0, int x1, int y1);
	~Button();
	void blit(SDL_Surface *screen);
	void check(int x, int y, bool &flip, SDL_Surface *screen);
	void checkAdd(int x, int y, int &level, int change, SDL_Surface *screen);
};
