#include "structs.h"

class Editor{
	Tile tile[MAXMAPSIZE][MAXMAPSIZE];
	SDL_Rect sprite[NUMLIGHT][NUMTILES];
	Location mapSize;
	Location pStart;
	Location sLoc;
	string file;
	ifstream in;
	ofstream out;
	SDL_Surface *items;
	SDL_Surface *lvlitems;
	SDL_Surface *terrain;
	SDL_Surface *other;
	SDL_Surface *background;
	int numLevels;
public:
	Editor(int level);
	~Editor();
	void edit();
	void blit(SDL_Surface *screen);
	bool inbounds(int x, int y);
	void clearTile();
	void clear();
	void clearItem();
	void setOther();
	void setItem(int check, int set);
	void setSize();
	void handleEvent(SDL_Surface *screen, SDL_Event &event, bool &quit, bool &save);
	void outputLevel();
};
