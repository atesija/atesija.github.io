Combine
Made by: Anthony Tesija
Wolverine Soft 48 hour competition
January 2012
Theme: combine

Story:
	A radical color demon has thrown you into a maze. There is only one way out, combine colors and open their corresponding doors. Avoid the demon's saw blade army and find your way to victory. If you make it to the exit the demon will let you go free.

How to play:
	Use w/a/s/d to move your player around the map. Avoid the moving saw blade enemies, they will kill you and you will have to restart. Press space to interact with objects. There are 3 different color orbs that can be found on the map (Red, Blue, and Yellow). Collect these and interact with the rainbow orb to combine them and make new colors. In the color menu use the mouse to select which of the 3 colors you will use to blend. You need at least 2 different ones to create a new color. Hit reset if you want to try again, or combine to create the new color. Creating a new color uses up the two that will be blended and removes the rainbow orb from the map so be careful with your combination. If you want to exit the color menu without changing anthing just hit backspace. As you walk around you'll notice colored blocks. In order to move the colored block you must have that same color in your inventory. Hit space and the block will vanish along with the color in your inventory. There are also rainbow blocks that require you to have one of every color in order to open. If you want to quit at any time just press escape.

How it fits into the theme:
	You collect colors in the game which can be used to unlock doors. In order to unlock every color door and find the exit you must combine colors at a rainbow orb.

Music:
Vintage Sunset - IMD007
chiploop - chubby-chobby

from newgrounds.com

Art and Code:
Anthony Tesija
